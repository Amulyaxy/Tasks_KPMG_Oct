In this script:

The get_nested_value function takes two parameters: object and key.
It uses the jq command to extract the value associated with the provided key from the JSON object.
The example usage section demonstrates how to call the function with different objects and keys.
Make sure you have jq installed on your system. You can install it using package managers like apt on Ubuntu or brew on macOS. Adjust the object and key variables as needed for your specific use case. When you run the script, it will output the values associated with the given keys in the example objects.