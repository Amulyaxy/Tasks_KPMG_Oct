In this script:

curl -s http://169.254.169.254/latest/meta-data/instance-id retrieves the instance ID.
curl -s http://169.254.169.254/latest/dynamic/instance-identity/document retrieves the instance metadata.
The script constructs a JSON object with the instance ID and the retrieved metadata.
If the instance ID is retrieved successfully, it prints the JSON-formatted output. Otherwise, it displays an error message.
Make sure to grant the necessary permissions to execute this script and ensure that curl is installed on your system. When you run this script on an AWS EC2 instance, it will output the instance metadata in JSON format.